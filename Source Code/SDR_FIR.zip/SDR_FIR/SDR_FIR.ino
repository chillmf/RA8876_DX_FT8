

/*
c
  - released
b
- Use FIR filters with fast_fft option

The audio board uses the following pins.
 6 - MEMCS
 7 - MOSI
 9 - BCLK
10 - SDCS
11 - MCLK
12 - MISO
13 - RX
14 - SCLK
15 - VOL
18 - SDA
19 - SCL
22 - TX
23 - LRCLK
*/

#include <Audio.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <SerialFlash.h>
#include "filters.h"
#include "AudioSDRpreProcessor.h"



// GUItool: begin automatically generated code
AudioSDRpreProcessor   preProcessor;

AudioInputI2S            i2s1;           //xy=120,212
AudioEffectMultiply      multiply2;      //xy=285,414
AudioEffectMultiply      multiply1;      //xy=287,149
AudioSynthWaveformSine   sine1;          //xy=289,244
AudioFilterFIR           fir1;           //xy=471,153
AudioFilterFIR           fir2;           //xy=472,413
AudioMixer4              mixer1;         //xy=666,173
AudioMixer4              mixer2;         //xy=675,406
AudioAmplifier           amp1;           //xy=859,151
AudioOutputI2S           i2s2;           //xy=868,258
AudioRecordQueue         queue1;         //xy=1027,149

AudioConnection c1(i2s1, 0,       preProcessor, 0);
AudioConnection c2(i2s1, 1,       preProcessor, 1);




AudioConnection          patchCord1(preProcessor, 0, multiply1, 0);
AudioConnection          patchCord2(preProcessor, 1, multiply2, 1);
AudioConnection          patchCord3(multiply2, fir2);
AudioConnection          patchCord4(multiply1, fir1);
AudioConnection          patchCord5(sine1, 0, multiply1, 1);
AudioConnection          patchCord6(sine1, 0, multiply2, 0);
AudioConnection          patchCord7(fir1, 0, mixer1, 0);
AudioConnection          patchCord8(fir1, 0, mixer2, 0);
AudioConnection          patchCord9(fir2, 0, mixer1, 1);
AudioConnection          patchCord10(fir2, 0, mixer2, 1);
AudioConnection          patchCord11(mixer1, 0, i2s2, 0);
AudioConnection          patchCord12(mixer2, 0, i2s2, 1);
AudioConnection          patchCord13(amp1, queue1);
AudioControlSGTL5000     sgtl5000_1;     //xy=404,516
// GUItool: end automatically generated code








void setup() {
  Serial.begin(9600);
  delay(300);

  // allocate memory for the audio library
  AudioMemory(8);

   preProcessor.startAutoI2SerrorDetection();  

  //AudioMemory(100);
  sgtl5000_1.enable();
  sgtl5000_1.inputSelect(AUDIO_INPUT_LINEIN);
  sgtl5000_1.lineInLevel(7);
  //sgtl5000_1.lineOutLevel(31);
  sgtl5000_1.volume(1);

  sine1.amplitude(1.0);
  sine1.frequency(10000);
  sine1.phase(0);


  fir1.begin(FIR_I, NUM_COEFFS);
  fir2.begin(FIR_Q, NUM_COEFFS);

  mixer1.gain(0, 0.4);
  mixer1.gain(1, 0.4);

  mixer2.gain(0, 0.4);
  mixer2.gain(1, -0.4);

  amp1.gain(1.0);
  queue1.begin();



  Serial.println("setup done");
}


unsigned long last_time = millis();

void loop()
{


 
  // print information about resource usage
  // Proc = 18 (18),  Mem = 4 (5)
  if (millis() - last_time >= 2500) {
    Serial.print("Proc = ");
    Serial.print(AudioProcessorUsage());
    Serial.print(" (");    
    Serial.print(AudioProcessorUsageMax());
    Serial.print("),  Mem = ");
    Serial.print(AudioMemoryUsage());
    Serial.print(" (");    
    Serial.print(AudioMemoryUsageMax());
    Serial.println(")");
    last_time = millis();
  }


}
